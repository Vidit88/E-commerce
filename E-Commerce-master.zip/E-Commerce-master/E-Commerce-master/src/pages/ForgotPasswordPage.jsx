import ForgotPassword from "../features/ForgotPassword"


const ForgotPasswordPage = ()=>{
    return (
        <div>
            <ForgotPassword></ForgotPassword>
        </div>
    )
}

export default ForgotPasswordPage